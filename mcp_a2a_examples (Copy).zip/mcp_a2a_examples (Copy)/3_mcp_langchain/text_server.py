"""Second MCP server: text utilities (runs over stdio)."""
from mcp.server.fastmcp import FastMCP
mcp = FastMCP("text")

@mcp.tool()
def to_upper(text: str) -> str:
    """Convert text to upper case."""
    return text.upper()

@mcp.tool()
def reverse(text: str) -> str:
    """Reverse a string."""
    return text[::-1]

if __name__ == "__main__":
    mcp.run(transport="stdio")
