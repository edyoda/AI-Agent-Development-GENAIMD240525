"""
MCP + LangChain

Compare with example 2: there we hand-wrote the tool conversion and the agent
loop. Here two libraries do that for us:
  * langchain-mcp-adapters : MCP tools  ->  LangChain tools (auto conversion)
  * langgraph              : ready-made ReAct agent loop (think -> tool -> think ...)

Bonus: MultiServerMCPClient connects to SEVERAL MCP servers at once and merges
all their tools into one list - the agent doesn't care where a tool lives.

Setup: export ANTHROPIC_API_KEY=...    Run: python client.py
"""
import os
import asyncio
import sys
from langchain_anthropic import ChatAnthropic
from langchain_mcp_adapters.client import MultiServerMCPClient
from langgraph.prebuilt import create_react_agent


# Optional: only needed if your API key is NOT scoped to a workspace
# (the API then demands an `anthropic-workspace-id` header).  export ANTHROPIC_WORKSPACE_ID=wrkspc_...
WORKSPACE_ID = os.environ.get("ANTHROPIC_WORKSPACE_ID")
HEADERS = {"anthropic-workspace-id": WORKSPACE_ID} if WORKSPACE_ID else None


async def main():
    # Describe each server: how to reach it (transport) and how to start it.
    client = MultiServerMCPClient({
        "math": {"command": sys.executable, "args": ["math_server.py"], "transport": "stdio"},
        "text": {"command": sys.executable, "args": ["text_server.py"], "transport": "stdio"},
        # A remote server would look like:
        # "remote": {"url": "http://localhost:8000/mcp", "transport": "streamable_http"},
    })

    # Discover tools from ALL servers -> list of LangChain tools
    tools = await client.get_tools()
    print("Loaded tools:", [t.name for t in tools])

    llm = ChatAnthropic(model="claude-sonnet-5", default_headers=HEADERS)

    # The agent = LLM + tools + loop. No manual while-loop needed.
    agent = create_react_agent(llm, tools)

    result = await agent.ainvoke({
        "messages": [("user",
            "Compute (3 + 5) * 12, then reverse the digits of the answer as a string "
            "and upper-case it.")]
    })

    # Last message is the final answer; earlier ones show the tool calls.
    for m in result["messages"]:
        print(f"[{m.type}]", getattr(m, "content", ""))


asyncio.run(main())
