"""
MCP SERVER  -  exposes capabilities to any MCP client.

MCP (Model Context Protocol) defines 3 kinds of things a server can offer:
  * TOOLS      - functions the LLM/app can CALL   (actions, model-controlled)
  * RESOURCES  - read-only DATA addressed by URI   (context, app-controlled)
  * PROMPTS    - reusable prompt templates         (user-controlled)

FastMCP turns plain Python functions into these using decorators. The type
hints and docstrings become the JSON schema + description the LLM sees.
"""
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("demo-server")          # the server's name


@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers."""            # <- docstring = tool description for the LLM
    return a + b


@mcp.tool()
def word_count(text: str) -> int:
    """Count the words in a piece of text."""
    return len(text.split())


@mcp.resource("greeting://{name}")     # URI template; {name} is passed to the function
def greeting(name: str) -> str:
    """A personalised greeting (read-only data)."""
    return f"Hello, {name}! Welcome to MCP."


@mcp.prompt()
def summarize(text: str) -> str:
    """Reusable prompt template."""
    return f"Summarize the following text in one sentence:\n\n{text}"


if __name__ == "__main__":
    # stdio transport: the client launches this file as a subprocess and talks
    # JSON-RPC over stdin/stdout. (Other transport: "streamable-http" for remote.)
    mcp.run(transport="stdio")
