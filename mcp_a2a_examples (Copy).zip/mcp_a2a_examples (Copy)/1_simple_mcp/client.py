"""
MCP CLIENT  -  connects to a server, discovers what it offers, calls it.
No LLM here: this shows the raw protocol flow.

Run:  python client.py     (it launches server.py itself)
"""
import asyncio
import sys
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

# How to START the server process (stdio transport = spawn a subprocess)
server_params = StdioServerParameters(command=sys.executable, args=["server.py"])


async def main():
    async with stdio_client(server_params) as (read, write):
        async with ClientSession(read, write) as session:
            # 1. Handshake: exchange protocol version + capabilities
            await session.initialize()

            # 2. DISCOVERY - the client asks the server what it has
            tools = await session.list_tools()
            print("TOOLS:", [t.name for t in tools.tools])
            for t in tools.tools:
                print(f"  - {t.name}: {t.description}  schema={t.inputSchema['properties']}")

            # 3. Call a TOOL
            result = await session.call_tool("add", {"a": 2, "b": 40})
            print("add(2, 40) ->", result.content[0].text)

            # 4. Read a RESOURCE by URI
            res = await session.read_resource("greeting://Asha")
            print("resource ->", res.contents[0].text)

            # 5. Fetch a PROMPT template
            prompt = await session.get_prompt("summarize", {"text": "MCP standardises tool access."})
            print("prompt ->", prompt.messages[0].content.text)


asyncio.run(main())
