"""
A2A SERVER  -  a "remote agent" that other agents can discover and talk to.

MCP vs A2A (the key distinction to teach):
  * MCP : agent  <->  TOOLS/DATA     (vertical: "give my agent hands")
  * A2A : agent  <->  another AGENT  (horizontal: "agents collaborate as peers")
          The other agent is opaque - you send it a task in natural language and
          it decides how to do it. You don't see its tools or internals.

A2A is JSON-RPC over HTTP with two main pieces:
  1. AGENT CARD  - public JSON at /.well-known/agent.json describing who the
                   agent is, what skills it has and where to send messages.
  2. TASKS       - client sends a `message/send`; server replies with a Task
                   holding a status and artifacts (the result).

This file implements the wire protocol by hand (FastAPI) so every step is
visible. In production use the official `a2a-sdk` which does this for you.
The agent's "brain" is a simple rule-based unit converter; in real life it
would be an LLM/LangGraph agent - the protocol layer is identical.

Run:  python remote_agent.py     (serves on http://localhost:9999)
"""
import re
import uuid
import uvicorn
from fastapi import FastAPI, Request

app = FastAPI()

# ---- 1. AGENT CARD: how other agents DISCOVER this one -------------------
AGENT_CARD = {
    "name": "Unit Converter Agent",
    "description": "Converts km<->miles and celsius<->fahrenheit.",
    "url": "http://localhost:9999/",              # where to send JSON-RPC calls
    "version": "1.0.0",
    "capabilities": {"streaming": False},
    "defaultInputModes": ["text"],
    "defaultOutputModes": ["text"],
    "skills": [{
        "id": "convert",
        "name": "Unit conversion",
        "description": "Convert distances and temperatures",
        "examples": ["convert 10 km to miles", "convert 100 celsius to fahrenheit"],
    }],
}

@app.get("/.well-known/agent.json")
def agent_card():
    return AGENT_CARD


# ---- The agent's actual logic (swap for an LLM in real apps) ------------
def do_work(text: str) -> str:
    m = re.search(r"([\d.]+)\s*(km|miles|celsius|fahrenheit)\s*to\s*(km|miles|celsius|fahrenheit)", text.lower())
    if not m:
        return "Sorry, I only understand e.g. 'convert 10 km to miles'."
    v, src, dst = float(m[1]), m[2], m[3]
    table = {
        ("km", "miles"): v * 0.621371,
        ("miles", "km"): v / 0.621371,
        ("celsius", "fahrenheit"): v * 9 / 5 + 32,
        ("fahrenheit", "celsius"): (v - 32) * 5 / 9,
    }
    if (src, dst) not in table:
        return f"Cannot convert {src} to {dst}."
    return f"{v} {src} = {table[(src, dst)]:.2f} {dst}"


# ---- 2. JSON-RPC endpoint: receives tasks ------------------------------
@app.post("/")
async def rpc(request: Request):
    req = await request.json()
    if req.get("method") != "message/send":
        return {"jsonrpc": "2.0", "id": req.get("id"),
                "error": {"code": -32601, "message": "Method not found"}}

    # A message is made of PARTS (text, file, data...). We read the text parts.
    parts = req["params"]["message"]["parts"]
    user_text = " ".join(p["text"] for p in parts if p.get("kind") == "text")

    answer = do_work(user_text)

    # Reply with a TASK: id + status + ARTIFACTS (the deliverable)
    return {
        "jsonrpc": "2.0",
        "id": req["id"],
        "result": {
            "kind": "task",
            "id": str(uuid.uuid4()),
            "status": {"state": "completed"},     # other states: working, input-required, failed
            "artifacts": [{
                "artifactId": str(uuid.uuid4()),
                "name": "result",
                "parts": [{"kind": "text", "text": answer}],
            }],
        },
    }


if __name__ == "__main__":
    uvicorn.run(app, host="localhost", port=9999)
