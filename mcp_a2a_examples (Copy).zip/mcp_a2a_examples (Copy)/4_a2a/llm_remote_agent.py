"""
A2A SERVER, LLM-POWERED  -  same protocol as remote_agent.py, smarter brain.

Only do_work() changed: instead of regexes, Claude answers the request.
Everything else (Agent Card, JSON-RPC `message/send`, Task + artifacts) is
identical. That's the point of A2A: callers depend on the PROTOCOL, not on
how the agent is implemented, so you can swap the brain freely.

Setup: export ANTHROPIC_API_KEY=...     Run: python llm_remote_agent.py  (port 9998)
"""
import os
import uuid
import uvicorn
from anthropic import Anthropic
from fastapi import FastAPI, Request

app = FastAPI()
# Optional: only needed if your API key is NOT scoped to a workspace
# (the API then demands an `anthropic-workspace-id` header).  export ANTHROPIC_WORKSPACE_ID=wrkspc_...
WORKSPACE_ID = os.environ.get("ANTHROPIC_WORKSPACE_ID")
HEADERS = {"anthropic-workspace-id": WORKSPACE_ID} if WORKSPACE_ID else None
llm = Anthropic(default_headers=HEADERS)
MODEL = "claude-sonnet-5"

# The agent's "personality" and scope live in the system prompt.
SYSTEM = (
    "You are a Travel Advisor agent. Give concise, practical travel advice "
    "(best season, budget, must-see items, one safety tip). Max 120 words."
)

# ---- AGENT CARD: how other agents (and their LLMs) learn what this agent can do
AGENT_CARD = {
    "name": "Travel Advisor Agent",
    "description": "Gives concise travel advice for a destination: season, budget, sights, safety.",
    "url": "http://localhost:9998/",
    "version": "1.0.0",
    "capabilities": {"streaming": False},
    "defaultInputModes": ["text"],
    "defaultOutputModes": ["text"],
    "skills": [{
        "id": "travel_advice",
        "name": "Travel advice",
        "description": "Advice for a destination in natural language",
        "examples": ["I have 5 days in Kyoto in November, what should I know?"],
    }],
}

@app.get("/.well-known/agent.json")
def agent_card():
    return AGENT_CARD


def do_work(user_text: str) -> str:
    """THE BRAIN: one LLM call. Could equally be a LangGraph agent with its own MCP tools."""
    resp = llm.messages.create(
        model=MODEL, max_tokens=600, system=SYSTEM,
        messages=[{"role": "user", "content": user_text}],
    )
    return "".join(b.text for b in resp.content if b.type == "text")


# Plain `def` (not async): FastAPI runs it in a thread pool, so the blocking
# LLM call doesn't freeze the server's event loop.
@app.post("/")
def rpc(req: dict):
    if req.get("method") != "message/send":
        return {"jsonrpc": "2.0", "id": req.get("id"),
                "error": {"code": -32601, "message": "Method not found"}}

    parts = req["params"]["message"]["parts"]
    user_text = " ".join(p["text"] for p in parts if p.get("kind") == "text")

    # A2A task states let the caller react: completed / failed / input-required ...
    try:
        state, answer = "completed", do_work(user_text)
    except Exception as e:                       # e.g. missing API key, rate limit
        state, answer = "failed", f"Agent error: {e}"

    return {
        "jsonrpc": "2.0",
        "id": req["id"],
        "result": {
            "kind": "task",
            "id": str(uuid.uuid4()),
            "status": {"state": state},
            "artifacts": [{
                "artifactId": str(uuid.uuid4()),
                "name": "result",
                "parts": [{"kind": "text", "text": answer}],
            }],
        },
    }


if __name__ == "__main__":
    uvicorn.run(app, host="localhost", port=9998)
