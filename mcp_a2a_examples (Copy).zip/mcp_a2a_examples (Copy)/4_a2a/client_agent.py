"""
A2A CLIENT  -  discovers a remote agent and delegates a task to it.

Flow:
  1. DISCOVER : GET /.well-known/agent.json  -> read the Agent Card
  2. DECIDE   : check the agent's skills match what we need
  3. DELEGATE : POST a JSON-RPC `message/send` to the URL from the card
  4. READ     : extract the text from the returned task's artifacts

Start remote_agent.py first, then:  python client_agent.py
"""
import uuid
import httpx

BASE = "http://localhost:9999"


def discover(base_url: str) -> dict:
    """Step 1: fetch the agent card - the 'business card' of a remote agent."""
    return httpx.get(f"{base_url}/.well-known/agent.json").raise_for_status().json()


def send_task(card: dict, text: str) -> str:
    """Step 3+4: send a message to the agent and return its text answer."""
    payload = {
        "jsonrpc": "2.0",
        "id": str(uuid.uuid4()),
        "method": "message/send",
        "params": {
            "message": {
                "role": "user",
                "messageId": str(uuid.uuid4()),
                "parts": [{"kind": "text", "text": text}],
            }
        },
    }
    resp = httpx.post(card["url"], json=payload, timeout=30).raise_for_status().json()
    if "error" in resp:
        raise RuntimeError(resp["error"])
    task = resp["result"]
    print("task state:", task["status"]["state"])
    return task["artifacts"][0]["parts"][0]["text"]


if __name__ == "__main__":
    card = discover(BASE)
    print(f"Found agent: {card['name']} - {card['description']}")
    print("Skills:", [s["name"] for s in card["skills"]])

    print("\nAnswer:", send_task(card, "convert 42 km to miles"))
    print("Answer:", send_task(card, "convert 100 celsius to fahrenheit"))
