"""
A2A CLIENT, LLM-POWERED ORCHESTRATOR  -  an agent that delegates to another agent.

Two LLMs, two processes, one protocol:

   User -> [Orchestrator (Claude)] --A2A--> [Travel Advisor (Claude)]

The orchestrator does NOT know the remote agent's internals. It only knows the
Agent Card. We turn that card into a TOOL description, so the orchestrator's
LLM can decide by itself whether/when to delegate. (Compare with MCP, where
the tools would be plain functions instead of another reasoning agent.)

Setup: export ANTHROPIC_API_KEY=...
Run:   python llm_remote_agent.py      (terminal 1)
       python llm_orchestrator.py      (terminal 2)
"""
import os
import uuid
import httpx
from anthropic import Anthropic

# Optional: only needed if your API key is NOT scoped to a workspace
# (the API then demands an `anthropic-workspace-id` header).  export ANTHROPIC_WORKSPACE_ID=wrkspc_...
WORKSPACE_ID = os.environ.get("ANTHROPIC_WORKSPACE_ID")
HEADERS = {"anthropic-workspace-id": WORKSPACE_ID} if WORKSPACE_ID else None
llm = Anthropic(default_headers=HEADERS)
MODEL = "claude-sonnet-5"
REMOTE_AGENT_URLS = ["http://localhost:9998"]     # agents we're allowed to talk to


# ---- A2A plumbing (same as client_agent.py) ------------------------------
def discover(base_url: str) -> dict:
    return httpx.get(f"{base_url}/.well-known/agent.json").raise_for_status().json()

def send_task(card: dict, text: str) -> str:
    payload = {
        "jsonrpc": "2.0", "id": str(uuid.uuid4()), "method": "message/send",
        "params": {"message": {"role": "user", "messageId": str(uuid.uuid4()),
                               "parts": [{"kind": "text", "text": text}]}},
    }
    # LLM agents are slow -> generous timeout
    resp = httpx.post(card["url"], json=payload, timeout=120).raise_for_status().json()
    if "error" in resp:
        return f"A2A error: {resp['error']}"
    task = resp["result"]
    answer = task["artifacts"][0]["parts"][0]["text"]
    # Surface non-success states so the orchestrator LLM can react
    return answer if task["status"]["state"] == "completed" else f"[{task['status']['state']}] {answer}"


# ---- Step 1: DISCOVER remote agents, index by name ------------------------
cards = {}
for url in REMOTE_AGENT_URLS:
    card = discover(url)
    cards[card["name"]] = card
    print(f"Discovered: {card['name']} - {card['description']}")

# ---- Step 2: expose them to the LLM as ONE tool ---------------------------
# The Agent Card text becomes the tool description => the LLM knows what each
# agent is good for. `enum` restricts it to agents we actually discovered.
agent_list = "\n".join(f"- {n}: {c['description']}" for n, c in cards.items())
tools = [{
    "name": "delegate_to_agent",
    "description": (
        "Delegate a task, written in natural language, to a remote specialist agent. "
        "Include all needed context; the agent can't see this conversation.\n"
        f"Available agents:\n{agent_list}"
    ),
    "input_schema": {
        "type": "object",
        "properties": {
            "agent_name": {"type": "string", "enum": list(cards)},
            "task": {"type": "string", "description": "What you want the agent to do"},
        },
        "required": ["agent_name", "task"],
    },
}]


def run(user_request: str):
    """Standard tool-use loop; the 'tool' happens to be another agent."""
    messages = [{"role": "user", "content": user_request}]
    while True:
        resp = llm.messages.create(
            model=MODEL, max_tokens=1024, tools=tools, messages=messages,
            system="You are a personal assistant. Use remote agents for specialist knowledge, "
                   "then give the user a short final answer.",
        )
        messages.append({"role": "assistant", "content": resp.content})
        if resp.stop_reason != "tool_use":
            return "".join(b.text for b in resp.content if b.type == "text")

        results = []
        for b in resp.content:
            if b.type == "tool_use":
                print(f"-> delegating to '{b.input['agent_name']}': {b.input['task']}")
                answer = send_task(cards[b.input["agent_name"]], b.input["task"])   # <- the A2A call
                print(f"<- agent replied ({len(answer)} chars)")
                results.append({"type": "tool_result", "tool_use_id": b.id, "content": answer})
        messages.append({"role": "user", "content": results})


if __name__ == "__main__":
    print("\nFINAL:", run("I'm going to Lisbon for a long weekend in March on a tight budget. "
                          "What should I plan for?"))
