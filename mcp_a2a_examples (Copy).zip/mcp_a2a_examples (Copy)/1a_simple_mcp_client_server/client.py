"""
MCP CLIENT  -  connects to an ALREADY RUNNING server by URL.

The client no longer knows how to start the server (no command/args, no
subprocess). It only needs the address. Start the server first, then:

Run (terminal 2):   python client.py
Optional:           python client.py http://other-host:8000/mcp
"""
import asyncio
import sys
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

SERVER_URL = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8000/mcp"


async def main():
    # streamablehttp_client opens the HTTP connection. It yields (read, write, get_session_id);
    # we only need the first two, exactly like stdio_client.
    async with streamablehttp_client(SERVER_URL) as (read, write, _):
        # From here on the code is IDENTICAL to the stdio version: the transport
        # is pluggable, the MCP protocol on top doesn't change.
        async with ClientSession(read, write) as session:
            await session.initialize()                       # handshake

            tools = await session.list_tools()               # discovery
            print("TOOLS:", [t.name for t in tools.tools])

            result = await session.call_tool("add", {"a": 2, "b": 40})
            print("add(2, 40) ->", result.content[0].text)

            result = await session.call_tool("word_count", {"text": "separate client and server"})
            print("word_count ->", result.content[0].text)

            res = await session.read_resource("greeting://Asha")
            print("resource ->", res.contents[0].text)

            prompt = await session.get_prompt("summarize", {"text": "MCP standardises tool access."})
            print("prompt ->", prompt.messages[0].content.text)


def root_cause(e: BaseException) -> BaseException:
    """anyio wraps errors in ExceptionGroups; unwrap to the real reason."""
    while getattr(e, "exceptions", None):
        e = e.exceptions[0]
    return e


try:
    asyncio.run(main())
except Exception as e:
    print(f"Could not talk to {SERVER_URL}. Is server.py running?\n  {type(root_cause(e)).__name__}: {root_cause(e)}")
    sys.exit(1)
