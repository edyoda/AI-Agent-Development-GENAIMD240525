# 1a - MCP client and server as separate processes

Same tools/resources/prompts as `../1_simple_mcp`, but over **streamable HTTP**
instead of stdio, so the two sides run independently.

```
terminal 1:  python server.py     # listens on http://127.0.0.1:8000/mcp
terminal 2:  python client.py     # connects by URL (run it as often as you like)
```
If port 8000 is already in use, pick another: `PORT=8010 python server.py` and
`python client.py http://127.0.0.1:8010/mcp`.
Stop the server with Ctrl+C. Try running several clients at once, or restarting
the client without touching the server. To reach the server from another
machine, set `host="0.0.0.0"` in `server.py` and pass the URL:
`python client.py http://<server-ip>:8000/mcp`.

| | `1_simple_mcp` (stdio) | `1a_simple_mcp_client_server` (HTTP) |
|---|---|---|
| Who starts the server | the client, as a subprocess | you, separately |
| Lifetime | dies with the client | independent, long-lived |
| Clients per server | one | many |
| Client needs | command + args | a URL |
| Typical use | local tools, desktop apps | shared/remote services |

![diagram](diagram.png)
