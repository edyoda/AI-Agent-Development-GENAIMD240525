"""
MCP SERVER  -  runs as its OWN long-lived process over HTTP.

Difference from 1_simple_mcp:
  * 1_simple_mcp : stdio transport. The client SPAWNS the server as a child
                   process, so they always start/stop together.
  * here         : streamable-http transport. The server listens on a port;
                   any number of clients can connect to it by URL, from any
                   terminal or machine, whenever they like.

Run (terminal 1):   python server.py      -> serving at http://127.0.0.1:8000/mcp
Port busy?          PORT=8010 python server.py   (then: python client.py http://127.0.0.1:8010/mcp)
"""
import os
from mcp.server.fastmcp import FastMCP

# host/port = where to listen. Use 0.0.0.0 to accept connections from other machines.
PORT = int(os.environ.get("PORT", "8000"))       # override with PORT=... if 8000 is taken
mcp = FastMCP("demo-server", host="127.0.0.1", port=PORT)


@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two numbers."""
    return a + b


@mcp.tool()
def word_count(text: str) -> int:
    """Count the words in a piece of text."""
    return len(text.split())


@mcp.resource("greeting://{name}")
def greeting(name: str) -> str:
    """A personalised greeting (read-only data)."""
    return f"Hello, {name}! Welcome to MCP."


@mcp.prompt()
def summarize(text: str) -> str:
    """Reusable prompt template."""
    return f"Summarize the following text in one sentence:\n\n{text}"


if __name__ == "__main__":
    # The MCP endpoint is served at  http://<host>:<port>/mcp
    mcp.run(transport="streamable-http")
