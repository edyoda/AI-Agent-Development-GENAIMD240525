"""MCP server with a couple of 'real world' tools the LLM can use."""
from datetime import datetime
from mcp.server.fastmcp import FastMCP

mcp = FastMCP("utility-server")

@mcp.tool()
def get_time() -> str:
    """Get the current date and time."""
    return datetime.now().isoformat(timespec="seconds")

@mcp.tool()
def multiply(a: float, b: float) -> float:
    """Multiply two numbers. Use this for any arithmetic - LLMs are unreliable at math."""
    return a * b

if __name__ == "__main__":
    mcp.run(transport="stdio")
