"""
MCP CLIENT + LLM  (host application)

Architecture:   User -> [Host app: this file] -> Claude API
                                 |
                                 +-> MCP server (tools)

KEY IDEA: MCP does not talk to the LLM. The HOST app is the glue:
  1. ask the MCP server what tools exist
  2. give those tool descriptions to the LLM
  3. when the LLM says "call tool X", forward that call to the MCP server
  4. feed the result back to the LLM until it gives a final answer

Setup:  export ANTHROPIC_API_KEY=...     Run: python client.py
"""
import os
import asyncio
import sys
from anthropic import Anthropic
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

MODEL = "claude-sonnet-5"
# Optional: only needed if your API key is NOT scoped to a workspace
# (the API then demands an `anthropic-workspace-id` header).  export ANTHROPIC_WORKSPACE_ID=wrkspc_...
WORKSPACE_ID = os.environ.get("ANTHROPIC_WORKSPACE_ID")
HEADERS = {"anthropic-workspace-id": WORKSPACE_ID} if WORKSPACE_ID else None
llm = Anthropic(default_headers=HEADERS)


async def main():
    params = StdioServerParameters(command=sys.executable, args=["server.py"])
    async with stdio_client(params) as (r, w), ClientSession(r, w) as session:
        await session.initialize()

        # STEP 1+2: convert MCP tool definitions -> Anthropic tool format.
        # (They are nearly identical: name / description / JSON schema.)
        mcp_tools = (await session.list_tools()).tools
        tools = [
            {"name": t.name, "description": t.description, "input_schema": t.inputSchema}
            for t in mcp_tools
        ]

        messages = [{"role": "user",
                     "content": "What time is it, and what is 17.5 multiplied by 42?"}]

        # AGENT LOOP: keep going while the model wants to use tools
        while True:
            resp = llm.messages.create(
                model=MODEL, max_tokens=1024, tools=tools, messages=messages
            )
            # Always keep the assistant turn in history
            messages.append({"role": "assistant", "content": resp.content})

            if resp.stop_reason != "tool_use":         # model is done
                print("\nFINAL ANSWER:", "".join(b.text for b in resp.content if b.type == "text"))
                break

            # STEP 3: run every tool the model asked for, via MCP
            tool_results = []
            for block in resp.content:
                if block.type == "tool_use":
                    print(f"-> LLM calls {block.name}({block.input})")
                    result = await session.call_tool(block.name, block.input)
                    text = result.content[0].text
                    print(f"<- MCP returned {text}")
                    tool_results.append({
                        "type": "tool_result",
                        "tool_use_id": block.id,        # links result to the request
                        "content": text,
                    })
            # STEP 4: send ALL results back in one user message
            messages.append({"role": "user", "content": tool_results})


asyncio.run(main())
