"""
MCP CLIENT + LLM (host application) connecting to a RUNNING server by URL.

   User -> [Host app: this file] -> Claude API
                  |
                  +--HTTP--> MCP server (already running in another terminal)

Same idea as 2_mcp_with_llm: MCP does not talk to the LLM, the HOST app is the
glue. Only the transport changed (URL instead of spawning a subprocess).

Setup:  export ANTHROPIC_API_KEY=...
Run:    python server.py     (terminal 1)
        python client.py     (terminal 2)      or: python client.py http://host:8010/mcp
"""
import os
import asyncio
import sys
from anthropic import Anthropic
from mcp import ClientSession
from mcp.client.streamable_http import streamablehttp_client

MODEL = "claude-sonnet-5"
SERVER_URL = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1:8000/mcp"
# Optional: only needed if your API key is NOT scoped to a workspace
# (the API then demands an `anthropic-workspace-id` header).  export ANTHROPIC_WORKSPACE_ID=wrkspc_...
WORKSPACE_ID = os.environ.get("ANTHROPIC_WORKSPACE_ID")
HEADERS = {"anthropic-workspace-id": WORKSPACE_ID} if WORKSPACE_ID else None
llm = Anthropic(default_headers=HEADERS)


async def main():
    async with streamablehttp_client(SERVER_URL) as (read, write, _):
        async with ClientSession(read, write) as session:
            await session.initialize()

            # STEP 1+2: ask the server what tools exist, convert to Anthropic format
            # (name / description / JSON schema map almost 1:1).
            mcp_tools = (await session.list_tools()).tools
            tools = [
                {"name": t.name, "description": t.description, "input_schema": t.inputSchema}
                for t in mcp_tools
            ]
            print("Tools from server:", [t["name"] for t in tools])

            messages = [{"role": "user",
                         "content": "What time is it, and what is 17.5 multiplied by 42?"}]

            # AGENT LOOP: continue while the model wants to use tools
            while True:
                resp = llm.messages.create(
                    model=MODEL, max_tokens=1024, tools=tools, messages=messages
                )
                messages.append({"role": "assistant", "content": resp.content})

                if resp.stop_reason != "tool_use":          # model is done
                    print("\nFINAL ANSWER:", "".join(b.text for b in resp.content if b.type == "text"))
                    break

                # STEP 3: forward each tool request to the MCP server over HTTP
                tool_results = []
                for block in resp.content:
                    if block.type == "tool_use":
                        print(f"-> LLM calls {block.name}({block.input})")
                        result = await session.call_tool(block.name, block.input)
                        text = result.content[0].text
                        print(f"<- MCP returned {text}")
                        tool_results.append({"type": "tool_result",
                                             "tool_use_id": block.id, "content": text})
                # STEP 4: return ALL results in one user message
                messages.append({"role": "user", "content": tool_results})


def root_cause(e: BaseException) -> BaseException:
    """anyio wraps errors in ExceptionGroups; unwrap to the real reason."""
    while getattr(e, "exceptions", None):
        e = e.exceptions[0]
    return e


try:
    asyncio.run(main())
except Exception as e:
    print(f"Failed ({SERVER_URL}). Is server.py running, and is ANTHROPIC_API_KEY set?\n"
          f"  {type(root_cause(e)).__name__}: {root_cause(e)}")
    sys.exit(1)
