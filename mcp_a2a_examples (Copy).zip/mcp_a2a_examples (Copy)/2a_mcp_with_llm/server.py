"""
MCP SERVER for the LLM example, running as its OWN process over HTTP.

Compared with 2_mcp_with_llm (stdio, client spawns the server), this server
is started separately and stays up, so several LLM apps could share it.

Run (terminal 1):   python server.py            -> http://127.0.0.1:8000/mcp
Port busy?          PORT=8010 python server.py
"""
import os
from datetime import datetime
from mcp.server.fastmcp import FastMCP

PORT = int(os.environ.get("PORT", "8000"))
mcp = FastMCP("utility-server", host="127.0.0.1", port=PORT)


@mcp.tool()
def get_time() -> str:
    """Get the current date and time."""
    return datetime.now().isoformat(timespec="seconds")


@mcp.tool()
def multiply(a: float, b: float) -> float:
    """Multiply two numbers. Use this for any arithmetic - LLMs are unreliable at math."""
    return a * b


if __name__ == "__main__":
    mcp.run(transport="streamable-http")
