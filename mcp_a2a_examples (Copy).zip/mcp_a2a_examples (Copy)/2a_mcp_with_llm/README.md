# 2a - MCP + LLM with client and server as separate processes

Same idea as `../2_mcp_with_llm` (host app connects Claude to MCP tools), but the
MCP server runs independently over **streamable HTTP**.

```
export ANTHROPIC_API_KEY=...
terminal 1:  python server.py     # http://127.0.0.1:8000/mcp   (PORT=8010 python server.py if busy)
terminal 2:  python client.py     # or: python client.py http://127.0.0.1:8010/mcp
```
The client asks the server for its tools, gives them to Claude, and forwards
Claude's tool requests back to the server until Claude produces a final answer.

| | `2_mcp_with_llm` (stdio) | `2a_mcp_with_llm` (HTTP) |
|---|---|---|
| Server started by | the client (subprocess) | you, separately |
| Server lifetime | dies with the client | long-lived, shareable |
| Client config | command + args | URL |

![diagram](diagram.png)
