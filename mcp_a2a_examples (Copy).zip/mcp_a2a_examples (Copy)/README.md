# MCP & A2A teaching examples
pip install -r requirements.txt     (Python 3.10+)

1_simple_mcp/     server.py + client.py   - raw protocol: tools, resources, prompts (no LLM)
1a_simple_mcp_client_server/  same as 1 but client and server run separately over HTTP (PORT env var if 8000 is busy)
2_mcp_with_llm/   server.py + client.py   - host app wires MCP tools into Claude (needs ANTHROPIC_API_KEY)
2a_mcp_with_llm/  same as 2 but the MCP server runs separately over HTTP
3_mcp_langchain/  2 servers + client.py   - LangChain/LangGraph agent over multiple MCP servers
4_a2a/            remote_agent.py + client_agent.py (rule-based, no deps); llm_remote_agent.py + llm_orchestrator.py (Claude on both sides)

Run each from inside its own folder. For 4_a2a run remote_agent.py first.

## Diagrams
Each folder has a `diagram.png` (editable Graphviz source in `diagram.dot`; re-render with
`dot -Tpng -Gdpi=150 diagram.dot -o diagram.png`).

| Folder | Diagram |
|---|---|
| `1_simple_mcp/` | ![simple MCP](1_simple_mcp/diagram.png) |
| `1a_simple_mcp_client_server/` | ![separate MCP](1a_simple_mcp_client_server/diagram.png) |
| `2_mcp_with_llm/` | ![MCP with LLM](2_mcp_with_llm/diagram.png) |
| `2a_mcp_with_llm/` | ![separate MCP with LLM](2a_mcp_with_llm/diagram.png) |
| `3_mcp_langchain/` | ![MCP with LangChain](3_mcp_langchain/diagram.png) |
| `4_a2a/` | ![A2A](4_a2a/diagram.png) |

## MCP vs A2A

They solve different problems and are designed to be used together.

| | **MCP** (Model Context Protocol) | **A2A** (Agent2Agent) |
|---|---|---|
| Connects | an agent/LLM app to **tools and data** | an agent to **another agent** |
| Direction | vertical: "give my agent hands" | horizontal: "let agents collaborate as peers" |
| The other side is | a function, resource or prompt template: transparent, deterministic, you see its schema | an autonomous agent: opaque, it reasons and decides how to do the work |
| Unit of work | a **tool call** (structured args in, result out) | a **task** (natural-language message in, task with status + artifacts out) |
| Discovery | `list_tools`, `list_resources`, `list_prompts` after connecting | **Agent Card** at `/.well-known/agent.json` (name, skills, URL) |
| Lifecycle | request/response | task states: `working`, `input-required`, `completed`, `failed`; supports long-running work and streaming |
| Wire format | JSON-RPC over stdio or streamable HTTP | JSON-RPC over HTTP |
| Who calls whom | the **host app** brings the LLM and the server together; the server never talks to the LLM | the client agent's LLM decides to delegate; the remote agent may run its own LLM and its own MCP tools |
| Examples here | `1_simple_mcp`, `2_mcp_with_llm`, `3_mcp_langchain` | `4_a2a` |

### Rule of thumb
- Need to **call a function or read data**? Use **MCP**.
- Need to **hand a goal to another agent** that has its own reasoning, tools and memory, possibly run by another team or vendor? Use **A2A**.

### How they fit together
```
User
 |
 v
[Orchestrator agent (LLM)]
 |-- MCP --> [Tool servers: files, DB, calculator]     <- its own hands
 |
 '-- A2A --> [Travel Advisor agent (LLM)]              <- a peer with its own brain
               '-- MCP --> [Booking API, maps]        <- that agent's own hands
```
Each agent uses MCP for its tools; agents use A2A to talk to each other. The
orchestrator never sees the Travel Advisor's tools, only its Agent Card and
the results it returns.

### Side-by-side in the code
- MCP tool call (`2_mcp_with_llm/client.py`): `session.call_tool("multiply", {"a": 17.5, "b": 42})`, an exact function with a schema.
- A2A task (`4_a2a/llm_orchestrator.py`): `send_task(card, "3 days in Lisbon on a budget?")`, a free-text goal to an agent that decides how to answer.
